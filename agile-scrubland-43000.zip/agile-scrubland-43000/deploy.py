from flask import Flask,request
from flask_cors import CORS
import requests
import mysql.connector
import urllib.request
from mysql.connector import Error
import json
app=Flask(__name__)
CORS(app)

url = 'https://api.jsonbin.io/b'
headers = {
  'Content-Type': 'application/json',
  'secret-key': '$2a$10$0abJnFeZ.FxrRVLp4QJkj.4h/Rww/jtu7/Wv/0/U.kFIAlfbl4ouC'
}


@app.route('/',methods=['GET','POST'])

def index():
    conn =mysql.connector.connect(host='sql7.freemysqlhosting.net',database='sql7293839',user='sql7293839',password='LaLL1LS4Ey')
    cursor=conn.cursor()
    
    username=request.args.get('username')      
    password=request.args.get('password')
    
    cursor.execute("select * from userdata where username='"+username+"' AND passwd='"+password+"'")
    row=cursor.fetchone()
    if row!=None:
      return row[1]
    else:
      return "null"


@app.route('/register',methods=['GET','POST'])

def register():
    conn =mysql.connector.connect(host='sql7.freemysqlhosting.net',database='sql7293839',user='sql7293839',password='LaLL1LS4Ey')
    cursor=conn.cursor()
   

    username=request.args.get('username') 
    firstname=request.args.get('firstname')
    lastname=request.args.get('lastname')  
    password=request.args.get('password')
    email=request.args.get('email') 
    deviceId=request.args.get('deviceId') 
   
    cursor.execute("select * from userdata where username='"+username+"'")
    row=cursor.fetchone()

    if row==None:

      sql = "INSERT INTO userdata (username,firstname,lastname,passwd,email,deviceId) VALUES (%s, %s,%s, %s,%s, %s)"
      val = (username,firstname,lastname,password,email,deviceId)
      cursor.execute(sql, val)
      conn.commit()
      url="http://henoktad2.atwebpages.com/create.php?username="+username+"&firstname="+firstname+"&lastname="+lastname
      response=urllib.request.urlopen(url)
      return "registered"


@app.route('/dataRetrivalGeneral',methods=['GET','POST'])

def dataRetrivalGeneral():
   
   username=request.args.get('username')
   reqData=request.args.get('reqData')
   url="http://henoktad2.atwebpages.com/read.php?username="+username
   response=urllib.request.urlopen(url)
   rawD=response.read()
   rawString=str(rawD, 'utf-8')
   json_acceptable_string = rawString.replace("'", "\"")
   data=json.loads(json_acceptable_string)
   return data[reqData]

@app.route('/dataRetrivalDetail',methods=['GET','POST'])

def dataRetrivalDetail():
   
   username=request.args.get('username')
   room_id=request.args.get('room_id')
   reqData=request.args.get('reqData')

   url="http://henoktad2.atwebpages.com/read.php?username="+username
   response=urllib.request.urlopen(url)
   rawD=response.read()
   rawString=str(rawD, 'utf-8')
   json_acceptable_string = rawString.replace("'", "\"")
   data=json.loads(json_acceptable_string)
   return data[room_id][reqData]

@app.route('/modifiedreader',methods=['GET','POST'])

   
def modifiedreader():

      username=request.args.get('username')
      room=request.args.get('room')
      parameter=request.args.get('parameter')

      url="http://henoktad2.atwebpages.com/modifiedreader.php?username="+username+"&room="+room+"&parameter="+parameter
      response=urllib.request.urlopen(url)
      data=response.read()
      data=data.decode("utf-8")
      data=data[2:].replace("\n","")
      return str(data)

@app.route('/modifier',methods=['GET','POST'])

   
def modifier():

      username=request.args.get('username')
      room=request.args.get('room')
      parameter=request.args.get('parameter')
      newdata=request.args.get('newdata')

      url="http://henoktad2.atwebpages.com/modifier.php?username="+username+"&room="+room+"&parameter="+parameter+"&newdata="+newdata
      response=urllib.request.urlopen(url)
    
      return "modified"   


@app.route('/home',methods=['GET','POST'])

   
def home():

      
      return "<h1>modified</h1>" 


   

   
   
